/*
Copyright 2019 Chad Harper (chad.harper@gmail.com)

Permission is hereby granted, free of charge, to any person obtaining 
a copy of this software and associated documentation files (the 
"Software"), to deal in the Software without restriction, including 
without limitation the rights to use, copy, modify, merge, publish, 
distribute, sublicense, and/or sell copies of the Software, and to 
permit persons to whom the Software is furnished to do so, subject to 
the following conditions:

The above copyright notice and this permission notice shall be 
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS 
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF 
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. 
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY 
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, 
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE 
OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.


See if you can code the answers to these questions!
(Answers are given at the bottom)
Given this database , code the SQL statement to list the following:

Assume my StitcherID = 1

1. All of the posts made by people who have Approved my ContactRequest
Columns to include: 
Their StitcherID, UserName, FirstName, and LastName, The StitchPostID, StitchPostText, and PostedDate of the StitchPost, and the CategoryName 

2. All of the posts made by people whose ContactRequests I have approved.
Columns to include: 
Their StitcherID, UserName, FirstName, and LastName, The StitchPostID, StitchPostText, and PostedDate of the StitchPost, and the CategoryName 

Bonus: Can you show both of those in ONE query?

3. All of the people who have approved my ContactRequest and a count of how many StitchPosts they've made ever (Note: they may have posted 0 times...)
Columns to Include: UserName and Count of Posts

4. All of the categories and how many posts have been made with that CategoryID (Note that there may be 0 posts. Also, what do we do about the posts with NULL categoryID?)
Columns to Include: CategoryName and Count of Posts
*/









-- SPOILER ALERT: Answers below!
SELECT
	Stitch_Stitcher.StitcherID
	, Stitch_Stitcher.UserName
	, Stitch_Stitcher.FirstName
	, Stitch_Stitcher.LastName
	, Stitch_StitchPost.StitchPostID
	, Stitch_StitchPost.StitchPostText
	, Stitch_StitchPost.PostedDate
	, ISNULL(Stitch_StitchPost.CategoryID, 999) as CategoryID
	, ISNULL(Stitch_Category.CategoryName, 'Uncategorized') AS CategoryName
FROM Stitch_StitchPost
JOIN Stitch_Stitcher ON Stitch_Stitcher.StitcherID = Stitch_StitchPost.StitcherID
JOIN Stitch_ContactRequest ON Stitch_Stitcher.StitcherID = Stitch_ContactRequest.RequestedID
JOIN Stitch_Stitcher me ON me.StitcherID = Stitch_ContactRequest.RequestorID
LEFT JOIN Stitch_Category ON Stitch_StitchPost.CategoryID = Stitch_Category.CategoryID
WHERE me.StitcherID = 1 and Stitch_ContactRequest.Approved = 1



--1 
SELECT
	Stitch_Stitcher.StitcherID
	, Stitch_Stitcher.UserName
	, Stitch_Stitcher.FirstName
	, Stitch_Stitcher.LastName
	, Stitch_StitchPost.StitchPostID
	, Stitch_StitchPost.StitchPostText
	, Stitch_StitchPost.PostedDate
	, Stitch_Category.CategoryName
FROM Stitch_StitchPost
JOIN Stitch_Stitcher		ON Stitch_Stitcher.StitcherID = Stitch_StitchPost.StitcherID
JOIN Stitch_ContactRequest	ON Stitch_ContactRequest.RequestedID = Stitch_Stitcher.StitcherID
JOIN Stitch_Stitcher me	ON Stitch_ContactRequest.RequestorID = me.StitcherID
LEFT JOIN Stitch_Category		ON Stitch_Category.CategoryID = Stitch_StitchPost.CategoryID
WHERE me.StitcherID = 1 AND Stitch_ContactRequest.Approved = 1

--2 
SELECT
	Stitch_Stitcher.StitcherID
	, Stitch_Stitcher.UserName
	, Stitch_Stitcher.FirstName
	, Stitch_Stitcher.LastName
	, Stitch_StitchPost.StitchPostID
	, Stitch_StitchPost.StitchPostText
	, Stitch_StitchPost.PostedDate
	, Stitch_Category.CategoryName
FROM Stitch_StitchPost
JOIN Stitch_Stitcher ON Stitch_Stitcher.StitcherID = Stitch_StitchPost.StitcherID
JOIN Stitch_ContactRequest ON Stitch_ContactRequest.RequestorID = Stitch_Stitcher.StitcherID
LEFT JOIN Stitch_Category ON Stitch_Category.CategoryID = Stitch_StitchPost.CategoryID
JOIN Stitch_Stitcher me ON Stitch_ContactRequest.RequestedID = me.StitcherID
WHERE me.StitcherID = 1 AND Stitch_ContactRequest.Approved = 1


-- BONUS
SELECT
	Stitch_Stitcher.StitcherID
	, Stitch_Stitcher.UserName
	, Stitch_Stitcher.FirstName
	, Stitch_Stitcher.LastName
	, Stitch_StitchPost.StitchPostID
	, Stitch_StitchPost.StitchPostText
	, Stitch_StitchPost.PostedDate
	, Stitch_Category.CategoryName
FROM Stitch_StitchPost
JOIN Stitch_Stitcher		ON Stitch_Stitcher.StitcherID = Stitch_StitchPost.StitcherID
JOIN Stitch_ContactRequest	ON Stitch_ContactRequest.RequestedID = Stitch_Stitcher.StitcherID
JOIN Stitch_Stitcher me	ON Stitch_ContactRequest.RequestorID = me.StitcherID
LEFT JOIN Stitch_Category		ON Stitch_Category.CategoryID = Stitch_StitchPost.CategoryID
WHERE me.StitcherID = 1 AND Stitch_ContactRequest.Approved = 1
UNION ALL
SELECT
	Stitch_Stitcher.StitcherID
	, Stitch_Stitcher.UserName
	, Stitch_Stitcher.FirstName
	, Stitch_Stitcher.LastName
	, Stitch_StitchPost.StitchPostID
	, Stitch_StitchPost.StitchPostText
	, Stitch_StitchPost.PostedDate
	, Stitch_Category.CategoryName
FROM Stitch_StitchPost
JOIN Stitch_Stitcher ON Stitch_Stitcher.StitcherID = Stitch_StitchPost.StitcherID
JOIN Stitch_ContactRequest ON Stitch_ContactRequest.RequestorID = Stitch_Stitcher.StitcherID
LEFT JOIN Stitch_Category ON Stitch_Category.CategoryID = Stitch_StitchPost.CategoryID
JOIN Stitch_Stitcher me ON Stitch_ContactRequest.RequestedID = me.StitcherID
WHERE me.StitcherID = 1 AND Stitch_ContactRequest.Approved = 1

-- 3
SELECT
	Stitch_Stitcher.UserName
	, COUNT(Stitch_StitchPost.StitchPostID) as CountOfPosts
FROM Stitch_StitchPost
JOIN Stitch_Stitcher ON Stitch_Stitcher.StitcherID = Stitch_StitchPost.StitcherID
JOIN Stitch_ContactRequest ON Stitch_ContactRequest.RequestorID = Stitch_Stitcher.StitcherID
LEFT JOIN Stitch_Category ON Stitch_Category.CategoryID = Stitch_StitchPost.CategoryID
JOIN Stitch_Stitcher me ON Stitch_ContactRequest.RequestedID = me.StitcherID
WHERE me.StitcherID = 1 AND Stitch_ContactRequest.Approved = 1
GROUP BY Stitch_Stitcher.UserName

--4
SELECT
	Stitch_Category.CategoryName
	, COUNT(Stitch_StitchPost.StitchPostID) as CountOfPosts
FROM Stitch_StitchPost
LEFT JOIN Stitch_Category ON Stitch_Category.CategoryID = Stitch_StitchPost.CategoryID
GROUP BY Stitch_Category.CategoryName

SELECT * FROM Stitch_StitchPost WHERE CategoryID IS NULL
-- Second Bonus??


-- Extra bonus. Peep the JOIN for Stitcher
SELECT
	Stitch_Stitcher.StitcherID
	, Stitch_Stitcher.UserName
	, Stitch_Stitcher.FirstName
	, Stitch_Stitcher.LastName
	, Stitch_StitchPost.StitchPostID
	, Stitch_StitchPost.StitchPostText
	, Stitch_StitchPost.PostedDate
	, ISNULL(Stitch_Category.CategoryName, 'Uncategorized') as Category
FROM Stitch_StitchPost
JOIN Stitch_Stitcher ON Stitch_Stitcher.StitcherID = Stitch_StitchPost.StitcherID
JOIN Stitch_ContactRequest ON (Stitch_ContactRequest.RequestorID = Stitch_Stitcher.StitcherID OR Stitch_ContactRequest.RequestedID = Stitch_Stitcher.StitcherID)
LEFT JOIN Stitch_Category ON Stitch_Category.CategoryID = Stitch_StitchPost.CategoryID
JOIN Stitch_Stitcher me ON (Stitch_ContactRequest.RequestorID = me.StitcherID OR Stitch_ContactRequest.RequestedID = me.StitcherID) AND (me.StitcherID <> Stitch_StitchPost.StitcherID)
WHERE Stitch_ContactRequest.Approved = 1
ORDER BY PostedDate

GO

CREATE VIEW vuStitchTimeline AS
SELECT
	me.StitcherID as MyID
	, Stitch_Stitcher.StitcherID
	, Stitch_Stitcher.UserName
	, Stitch_Stitcher.FirstName
	, Stitch_Stitcher.LastName
	, Stitch_StitchPost.StitchPostID
	, Stitch_StitchPost.StitchPostText
	, Stitch_StitchPost.PostedDate
	, ISNULL(Stitch_Category.CategoryName, 'Uncategorized') as Category
FROM Stitch_StitchPost
JOIN Stitch_Stitcher ON Stitch_Stitcher.StitcherID = Stitch_StitchPost.StitcherID
JOIN Stitch_ContactRequest ON (Stitch_ContactRequest.RequestorID = Stitch_Stitcher.StitcherID OR Stitch_ContactRequest.RequestedID = Stitch_Stitcher.StitcherID)
LEFT JOIN Stitch_Category ON Stitch_Category.CategoryID = Stitch_StitchPost.CategoryID
JOIN Stitch_Stitcher me ON (Stitch_ContactRequest.RequestorID = me.StitcherID OR Stitch_ContactRequest.RequestedID = me.StitcherID) AND (me.StitcherID <> Stitch_StitchPost.StitcherID)
WHERE Stitch_ContactRequest.Approved = 1

GO

SELECT * FROM vuStitchTimeline WHERE MyID = 3 ORDER BY PostedDate DESC

select * from Stitch_Stitcher