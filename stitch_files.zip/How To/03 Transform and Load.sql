-- "Transform" and Load
INSERT INTO Stitch_Stitcher (UserName, FirstName, LastName, AboutMe)
SELECT UserName, FirstName, LastName, AboutMe FROM Stitchers$

INSERT INTO Stitch_Category (CategoryName, CategoryDescription)
SELECT CategoryName, Description FROM Category$

INSERT INTO Stitch_ContactRequest (RequestedDate, RequestedID, RequestorID, Approved)
SELECT RequestedDate, RequestedID, RequestorID, Approved FROM ContactRequest$

INSERT INTO Stitch_StitchPost (PostedDate, StitcherID, StitchPostText, CategoryID)
SELECT PostedDate, StitcherID, StitchPostText, CategoryID FROM StitchPost$
