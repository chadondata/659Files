-- Add drops for $ tables

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Stitch_StitchPost') 
BEGIN
	DROP TABLE Stitch_StitchPost
END

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Stitch_Category') 
BEGIN
	DROP TABLE Stitch_Category
END

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Stitch_ContactRequest') 
BEGIN
	DROP TABLE Stitch_ContactRequest
END

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Stitch_Stitcher') 
BEGIN
	DROP TABLE Stitch_Stitcher
END

CREATE TABLE Stitch_Stitcher (
	StitcherID int identity primary key,
	UserName varchar(30) NOT NULL unique,
	FirstName varchar(30) NOT NULL,
	LastName varchar(30) NOT NULL,
	AboutMe varchar(200),
	LastStitchPost int
)

CREATE TABLE Stitch_ContactRequest (
	  ContactRequestID int identity primary key
	, RequestedDate datetime not null default GetDate()
	, Approved bit 
	, RequestorID int not null
	, RequestedID int not null
	, CONSTRAINT fk_Requestor FOREIGN KEY (RequestorID) REFERENCES Stitch_Stitcher(StitcherID)
	, CONSTRAINT fk_Requested FOREIGN KEY (RequestedID) REFERENCES Stitch_Stitcher(StitcherID)
)


CREATE TABLE Stitch_Category
	(
	CategoryId			int identity primary key,
	CategoryName		varchar(30) NOT NULL unique,
	CategoryDescription	varchar(255) NOT NULL
   )


Create Table Stitch_StitchPost (
	StitchPostID		int identity primary key
	, StitchPostText	varchar(140) NOT NULL
	, PostedDate		datetime NOT NULL default GetDate()
	, StitcherID		int NOT NULL FOREIGN KEY REFERENCES Stitch_Stitcher(StitcherID)
	, CategoryID		int FOREIGN KEY REFERENCES Stitch_Category(CategoryID)
)

select * from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME LIKE 'Stitch_%'
