/*
Copyright 2019 Chad Harper (chad.harper@gmail.com)

Permission is hereby granted, free of charge, to any person obtaining 
a copy of this software and associated documentation files (the 
"Software"), to deal in the Software without restriction, including 
without limitation the rights to use, copy, modify, merge, publish, 
distribute, sublicense, and/or sell copies of the Software, and to 
permit persons to whom the Software is furnished to do so, subject to 
the following conditions:

The above copyright notice and this permission notice shall be 
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS 
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF 
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. 
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY 
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, 
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE 
OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

*/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Category$') 
BEGIN
	DROP TABLE Category$
END

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'ContactRequest$') 
BEGIN
	DROP TABLE ContactRequest$
END

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Stitchers$') 
BEGIN
	DROP TABLE Stitchers$
END

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'StitchPost$') 
BEGIN
	DROP TABLE StitchPost$
END

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Stitch_StitchPost') 
BEGIN
	DROP TABLE Stitch_StitchPost
END

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Stitch_Category') 
BEGIN
	DROP TABLE Stitch_Category
END

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Stitch_ContactRequest') 
BEGIN
	DROP TABLE Stitch_ContactRequest
END

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Stitch_Stitcher') 
BEGIN
	DROP TABLE Stitch_Stitcher
END

CREATE TABLE Stitch_Stitcher (
	StitcherID int identity primary key,
	UserName varchar(30) NOT NULL unique,
	FirstName varchar(30) NOT NULL,
	LastName varchar(30) NOT NULL,
	AboutMe varchar(200),
	LastStitchPost int
)

CREATE TABLE Stitch_ContactRequest (
	  ContactRequestID int identity primary key
	, RequestedDate datetime not null default GetDate()
	, Approved bit 
	, RequestorID int not null
	, RequestedID int not null
	, CONSTRAINT fk_Requestor FOREIGN KEY (RequestorID) REFERENCES Stitch_Stitcher(StitcherID)
	, CONSTRAINT fk_Requested FOREIGN KEY (RequestedID) REFERENCES Stitch_Stitcher(StitcherID)
)


CREATE TABLE Stitch_Category
	(
	CategoryID			int identity primary key,
	CategoryName		varchar(30) NOT NULL unique,
	CategoryDescription	varchar(255) NOT NULL
   )


Create Table Stitch_StitchPost (
	StitchPostID		int identity primary key
	, StitchPostText	varchar(140) NOT NULL
	, PostedDate		datetime NOT NULL default GetDate()
	, StitcherID		int NOT NULL FOREIGN KEY REFERENCES Stitch_Stitcher(StitcherID)
	, CategoryID		int FOREIGN KEY REFERENCES Stitch_Category(CategoryID)
)

select * from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME LIKE 'Stitch_%'
