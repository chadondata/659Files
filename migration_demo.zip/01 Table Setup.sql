/*
The following steps will import the CRM data into your database
000 Prerequisites
	You will need a database to work with. On remote lab, you can use the same database
	you've been using for class (table names are such that there won't be conflicts

001 Initialize tables
	Run the statements in this script between the 001 Start and 001 End comments

002 Import CSV data into staging tables

003 Load from staging into live tables
	Run the statements in this script between the 003 Start and 003 End comments

004 Optional: Cleanup
	Optionally, once the data are imported, re-run the "Clean up import tables" code below

005 Try it out!
*/

-- 001 Start Initialization Here

-- Clean up live tables
drop table if exists crm_contact
drop table if exists crm_job_title
drop table if exists crm_company

-- Clean up import tables
drop table if exists stage_crm_contact
drop table if exists stage_crm_job_title
drop table if exists stage_crm_company

-- Create live tables
create table crm_company (
	company_id int identity primary key
	, company_name varchar(50) not null unique
)

create table crm_job_title (
	job_title_id int identity primary key
	, job_title varchar(50) not null unique
)

create table crm_contact (
	contact_id int identity primary key
	, first_name varchar(50) not null
	, last_name varchar(50) not null
	, email varchar(50) not null
	, job_title_id int not null foreign key references crm_job_title(job_title_id)
	, company_id int not null foreign key references crm_company(company_id)
)

-- 001 End Initialization Here

-- 003 Start Load into Live here
INSERT INTO crm_company (company_name)
	SELECT company_name from stage_crm_company

INSERT INTO crm_job_title (job_title)
	SELECT job_title from stage_crm_job_title

INSERT INTO crm_contact (first_name, last_name, email, job_title_id, company_id)
	SELECT first_name, last_name, email, job_title_id, company_id from stage_crm_contact

-- 003 End Load into Live here

-- 005 Start Try it out! Code
-- Let's see everything
SELECT
	*
FROM crm_contact c
	join crm_job_title j on c.job_title_id = j.job_title_id
	join crm_company p on c.company_id = p.company_id

-- Which companies do I have more than one contact for?
SELECT
	p.company_name
	, count(c.contact_id) as NumContacts
FROM crm_contact c
	join crm_company p on c.company_id = p.company_id
GROUP BY p.company_name
HAVING count(c.contact_id) > 1

-- What are the 10 most frequent job titles in our contact list?
SELECT TOP 10
	j.job_title
	, count(c.contact_id) as NumContacts
FROM crm_contact c
	join crm_job_title j on c.job_title_id = j.job_title_id
GROUP BY j.job_title
HAVING count(c.contact_id) > 1
ORDER BY NumContacts DESC

-- 005 End Try it code
